# Telegram Music Downloader Bot
## Description
<a href="https://telegram.org/">Telegram</a> bot to download mp3 from YouTube.

Click <a href="https://t.me/TLMusicDownloader_bot">@TLMusicDownloader_bot</a> to see.


## Install dependencies

- Install telepotpro framework

        pip3 install telepotpro

 - Install youtube-dl

        pip3 install youtube-dl

 - Install youtube-search-python
 
        pip3 install youtube-search-python


## Screenshot
<img src="https://user-images.githubusercontent.com/58452863/93033272-91392e80-f603-11ea-9aae-8183131cefd1.png" alt="Screenshot" width="380" height="600">
